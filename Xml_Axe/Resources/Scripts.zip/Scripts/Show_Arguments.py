#!/usr/bin/python

import sys

try:
    Argument_Count = len(sys.argv) -1 # -1 because we don't count the filename at slot 0
    
    if (Argument_Count > 0):     
        print("Argument List:", str(sys.argv[1:]))   
        print("Number of arguments:", str(Argument_Count), "arguments.\n\n")
        
        for i in range(1, Argument_Count + 1):
          print(str(i) + " Argument:",  str(sys.argv[i]) + "\n")
    else: 
        print("No arguments were passed.")
       
except: print("No arguments were passed.")


input("\n\nPress enter to exit.\n")