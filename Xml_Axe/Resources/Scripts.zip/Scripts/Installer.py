# ===========================================================================================
#                           Pip Install function by Imperial
# ===========================================================================================        
try:
    from pip import main as pipmain # for backwards compability purposes
except ImportError:
    from pip._internal import main as pipmain 
  
     
  
# add parameter 2 as False to uninstall
# Example:  Install("lxml") or Install("lxml", False)
 
# ===========================================================================================
#                                     PIP FUNCTIONS
# =========================================================================================== 
def Install(Module_Name, Mode = True): 
    if Mode != True:
        pipmain(['uninstall', Module_Name])
        
    else:
        try:
            import lxml
            print(f"\nModule {Module_Name} is already installed\n")
                
        except ModuleNotFoundError: # If not found we try to install it
            print(f"\nInstalling module {Module_Name}...\n")        
            pipmain(["install", Module_Name])
            
            
# ===========================================================================================
#                                       END OF FILE
# =========================================================================================== 
            
            

    
    
    
    
    

        

    


