# ===========================================================================================
# DESCRIPTION:
# This script lists all texture files that are used for terrain in map files in the specific folder.
# Writes a report in the same folder.
# ===========================================================================================
import json
import os
import re
import sys 

# ===========================================================================================
# SETTINGS     
# ===========================================================================================
# hard string: 
mod_path = r'C:\Program Files (x86)\Steam\steamapps\common\Star Wars Empire at War\corruption\Mods\Scifi_At_War\Data' 


# Path to your mod's folder
try:
    mod = str(sys.argv[1]) # passed as argument 1    
except:    
    mod = mod_path 
    print(f'\n\nMod path is no passed variable.\n\nTrying: {mod}\n')


# Path to the folder with maps
path = fr"{mod}\Art\Maps"

# ===========================================================================================
# Program Body
# ===========================================================================================


pre_ted_tex = re.compile(br'\x0c[\x00-\xFF]([\x20-\x7E]*?)\x00\x13[\x00-\xFF]([\x20-\x7E]*?)\x00\x12\x01(?:[\x00-\xFF]{73})')

result = {}

for file_ in os.listdir(path):
    file = str.lower(file_)
    if file.endswith('.ted'):
        print(file)
        if file not in result:
            result[file] = []
        file_content = open(f'{path}\\{file_}', mode='rb').read()
        n = 0
        for match in re.finditer(pre_ted_tex, file_content):
            texture_file = match[1].decode('utf8').lower()
            normal_file = match[2].decode('utf8').lower()
            n += 1
            # print('\t', n, texture_file, normal_file)
            if texture_file not in result[file] and texture_file != '':
                result[file].append(texture_file)
            if normal_file not in result[file] and normal_file != '':
                result[file].append(normal_file)

with open(f'{path}\\maps_textures.txt', 'w') as fp:
    json.dump(result, fp, indent=4)



input("\n\n\nFinished! Press any Key to exit.\n")
# ===========================================================================================
# End of File
# ===========================================================================================