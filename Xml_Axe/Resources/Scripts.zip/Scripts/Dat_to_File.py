# ===========================================================================================
# DESCRIPTION:
# This script crawls through MasterTextFile_***.dat text files and exports them to a single .tsv (tab-separated) file.
# .tsv has string keys as first column and then one column for each language, language names in the first line.
# ===========================================================================================
import os
import re
import struct
import sys # gets passed arguments


# ===========================================================================================
# SETTINGS     
# ===========================================================================================

default_format = 'tsv'
default_delimiter = '\t'
mod_path = r'C:\Program Files (x86)\Steam\steamapps\common\Star Wars Empire at War\corruption\Mods\Scifi_At_War\Data' 



try:
    mod = str(sys.argv[1]) # passed as argument 1    
except:    
    mod = mod_path 
    print(f'\n\nMod path is no passed variable.\n\nTrying: {mod}\n')
    
    
try:
    delimiter = str(sys.argv[2])    
    print(f'\nReceived {delimiter} as delimiter sign.\n')
except:    
    delimiter = default_delimiter
    print(f'\n\nDelimiter is no passed variable.\n\nUsing \'tab\'\n')
    
try:
    format = str(sys.argv[3])    
except:    
    format = default_format
    print(f'\n\nFormat is no passed variable.\n\nUsing: {format}\n')

# ===========================================================================================
# Program Body
# ===========================================================================================


text_file_pattern = re.compile(r'^MasterTextFile_(.*?)\.dat$', re.IGNORECASE)


def import_file(file, language):
    with open(file, mode='rb') as file:
        file_content = file.read()
    number_of_items = struct.unpack("i", file_content[:4])[0]
    items = {}
    text_len = 0
    for i in range(number_of_items):
        items[i] = struct.unpack("iii", file_content[(4+i*12):(4+(i+1)*12)])
        text_len += items[i][1] * 2
    pos_text = 4 + number_of_items * 12
    pos_id = pos_text + text_len

    for i, (ik, iv) in enumerate(items.items()):
        entry_key = file_content[pos_id:pos_id+iv[2]].decode('utf8')
        entry_text = file_content[pos_text:pos_text+iv[1]*2].decode('utf-16-le')
        if entry_key not in imported_texts:
            imported_texts[entry_key] = {language: entry_text}
        else:
            imported_texts[entry_key][language] = entry_text
        pos_text += iv[1]*2
        pos_id += iv[2]


imported_texts = {}
result_file = open(f'{mod}\\Text\MasterTextFile.{format}', 'w', encoding='utf8')
result_file.write('NAME')
languages = []
for file in os.listdir(mod + r'\Text'):
    if text_file_pattern.match(file):
        lang = text_file_pattern.search(file).group(1)
        import_file(os.path.join(mod + r'\Text', file), lang)
        languages.append(lang)
        result_file.write(f'{delimiter}{lang}')
result_file.write('\n')
for key in sorted(imported_texts):
    result_file.write(f'{key}')
    for l in languages:
        if l not in imported_texts[key]:
            imported_texts[key][l] = ''
        result_file.write(f'{delimiter}{imported_texts[key][l]}')
    result_file.write('\n')
result_file.close()


input("\n\n\nFinished! Press any Key to exit.\n")
# ===========================================================================================
# END OF FILE
# ===========================================================================================
