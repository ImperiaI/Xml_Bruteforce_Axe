# ===========================================================================================
# DESCRIPTION:
# This script crawls through multiplayer map files in a mod (those which contain "_mp_" prefix in their names)
# and edits one byte so the game won't show them as Custom Maps.
# Thanks to [TEM] Lany for this solution.
# ===========================================================================================
import os
import sys 


# ===========================================================================================
# SETTINGS     
# ===========================================================================================
mod_path = r'C:\Program Files (x86)\Steam\steamapps\common\Star Wars Empire at War\corruption\Mods\Scifi_At_War\Data' 

# Path to your mod's folder
try:
    mod = str(sys.argv[1]) # passed as argument 1    
except:    
    mod = mod_path 
    print(f'\n\nMod path is no passed variable.\n\nTrying: {mod}\n')

# ===========================================================================================
# END OF SETTINGS     
# ===========================================================================================

for file_ in os.listdir(f'{mod}\\Art\\Maps'):
    file = str.lower(file_)
    if '_mp_' in file and file.endswith('.ted') and 'test' not in file:
        print(f'{file} processed.')
        file_content = open(f'{mod}\\Art\\Maps\\{file}', mode='rb+')
        file_content.seek(int('0x3a', 0))
        file_content.seek(int('0x3a', 0))
        file_content.write(b'\x00')
        file_content.close()


input("\n\n\nDone! Press any Key to exit.\n")