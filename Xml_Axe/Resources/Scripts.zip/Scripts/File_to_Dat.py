# ===========================================================================================
# DESCRIPTION:
# This script script reads .tsv (tab-separated) file and creates MasterTextFile_***.dat text files from it.
# .tsv has string keys as first column and then one column for each language, language names in the first line.
# ===========================================================================================
import csv
from zlib import crc32
import sys 


# ===========================================================================================
# SETTINGS     
# ===========================================================================================

default_format = 'tsv'
default_delimiter = '\t'
mod_path = r'C:\Program Files (x86)\Steam\steamapps\common\Star Wars Empire at War\corruption\Mods\Scifi_At_War\Data' 


try:
    mod = str(sys.argv[1]) # passed as argument 1    
except:    
    mod = mod_path 
    print(f'\n\nMod path is no passed variable.\n\nTrying: {mod}\n')
    
    
try:
    the_delimiter = str(sys.argv[2])    
except:    
    the_delimiter = default_delimiter
    print(f'\n\nDelimiter is no passed variable.\n\nUsing \'tab\'\n')
    
try:
    format = str(sys.argv[3])    
except:    
    format = default_format
    print(f'\n\nFormat is no passed variable.\n\nUsing: {format}\n')



# Path to your mod's .tsv text file
file_path = fr"{mod}\Text\MasterTextFile.{format}"

# ===========================================================================================
# Program Body
# ===========================================================================================


start_file = open(file_path, 'r', encoding='utf8')
tsvreader = csv.reader(start_file, delimiter = the_delimiter)
languages = []
data = []
for ln, line in enumerate(tsvreader):
    if ln == 0:
        languages = line[1:]
    else:
        temp_line = {'NAME': str(line[0])}
        for lang_n, language in enumerate(languages):
            temp_line[language] = str(line[lang_n + 1])
        data.append(temp_line)

for language in languages:
    print(f'Exporting {language}')
    out_dat = open(fr"{mod}\Text\MasterTextFile_{language}.dat", 'wb')

    text_prepared = {}
    for row in data:
        text_key = str(row['NAME'])
        text_val = str(row[language])
        text_id = crc32(text_key.encode('utf-8'))
        text_prepared[text_id] = (text_key, text_val)

    number_of_items = len(text_prepared)
    out_dat.write(number_of_items.to_bytes(length=4, byteorder='little', signed=False))

    for t_id in sorted(text_prepared):
        (tk, tv) = text_prepared[t_id]
        out_dat.write(t_id.to_bytes(length=4, byteorder='little', signed=False))
        out_dat.write(len(tv).to_bytes(length=4, byteorder='little', signed=False))
        out_dat.write(len(tk).to_bytes(length=4, byteorder='little', signed=False))

    for t_id in sorted(text_prepared):
        (_, tv) = text_prepared[t_id]
        out_dat.write(tv.encode('utf-16-le'))

    for t_id in sorted(text_prepared):
        (tk, _) = text_prepared[t_id]
        out_dat.write(tk.encode('utf8'))

    out_dat.close()   
    print(f'\t{number_of_items} lines exported.\n')
    
    
input("\n\n\nFinished! Press any Key to exit.\n")
# ===========================================================================================
# END OF FILE
# ===========================================================================================

